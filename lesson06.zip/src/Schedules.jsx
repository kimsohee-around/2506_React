import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css"; // 캘린더 기본 스타일
import { useSchedules } from "./hooks/useSchedules";
import TodosCardList from "./TodosCardList";
import TodosList from "./TodosList";
import TodoForm from "./components/TodoForm";
import LoadingSpinner from "./components/LoadingSpinner";
import ErrorMessage from "./components/ErrorMessage";
import { dateFormat } from "./utils/dateUtils";

export default function Schedules() {
  const {
    schedules,
    selectedSchedule,
    sortedSchedules,
    loading,
    error,
    selectScheduleByDate,
    updateCheckedStatus,
    deleteTodo,
    addTodo,
  } = useSchedules();

  const [calendarDate, setCalendarDate] = useState(new Date());

  const handleDateChange = (date) => {
    setCalendarDate(date);
    const selDate = dateFormat(date);
    selectScheduleByDate(selDate);
  };

  if (loading) {
    return <LoadingSpinner message="스케줄을 불러오는 중..." />;
  }

  if (error) {
    return (
      <ErrorMessage message={error} onRetry={() => window.location.reload()} />
    );
  }

  if (!schedules || schedules.length === 0) {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        <h3>스케줄 데이터가 없습니다.</h3>
        <TodoForm onAddTodo={addTodo} />
      </div>
    );
  }

  // if (!selectedSchedule) {
  //   return (
  //     <div style={{ padding: "20px", textAlign: "center" }}>
  //       선택된 스케줄이 없습니다.
  //     </div>
  //   );
  // }

  return (
    <div
      className="container"
      style={{
        padding: "20px",
        margin: "0 auto",
      }}
    >
      <h2 style={{ textAlign: "center", color: "#333", marginBottom: "2rem" }}>
        일정 관리
      </h2>

      {/* 캘린더 UI */}
      <div style={{ display: "flex" }}>
        <div style={{ margin: "30px", width: "380px", textAlign: "center" }}>
          <Calendar
            onChange={handleDateChange}
            value={calendarDate}
            locale="ko-KR"
            formatDay={(locale, date) => date.getDate()}
            tileContent={({ date, view }) => {
              if (view === "month") {
                const dateStr = dateFormat(date);
                const hasSchedule = schedules.some((s) => s.date === dateStr);
                return hasSchedule ? (
                  <div
                    style={{
                      textAlign: "center",
                      color: "pink",
                      fontSize: "1.2rem",
                    }}
                  >
                    ●
                  </div>
                ) : null;
              }
              return null;
            }}
          />

          {/* 새 할일 추가 */}
          <TodoForm
            calendarDate={dateFormat(calendarDate)}
            onAddTodo={addTodo}
          />
          <hr style={{ margin: "2rem 0" }} />
        </div>

        <div style={{ marginBottom: "2rem", width: "400px" }}>
          <h3 style={{ color: "#333", marginBottom: "1rem" }}>
            📅 {selectedSchedule?.date}
          </h3>

          {selectedSchedule &&
          selectedSchedule.todos &&
          selectedSchedule.todos.length > 0 ? (
            <>
              <hr style={{ margin: "2rem 0" }} />
              <TodosCardList
                todos={selectedSchedule.todos}
                onCheckedUpdate={updateCheckedStatus}
                onRemoved={deleteTodo}
              />
            </>
          ) : (
            <p
              style={{
                color: "#666",
                fontStyle: "italic",
                textAlign: "center",
                padding: "2rem",
              }}
            >
              이 날짜에 등록된 할일이 없습니다.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
